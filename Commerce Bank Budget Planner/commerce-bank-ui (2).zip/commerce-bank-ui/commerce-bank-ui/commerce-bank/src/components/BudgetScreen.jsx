import React, { useState, useEffect } from "react";
import IncomeSection from "./IncomeSection";
import FixedExpensesSection from "./FixedExpensesSection";
import VariableExpensesSection from "./VariableExpensesSection";
import SavingsGoalsSection from "./SavingsGoalsSection";
import BudgetService from "../api/BudgetService";
import { useNavigate } from "react-router-dom";
import { FaArrowLeft } from "react-icons/fa"; // FontAwesome back icon
import "../css/BudgetScreen.css"

const BudgetScreen = () => {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [budgetData, setBudgetData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDataAvailable, setIsDataAvailable] = useState(true);
  const [newBudgetName, setNewBudgetName] = useState(''); // For new budget creation
  const navigate = useNavigate();

  const fetchBudget = async () => {
    setIsLoading(true);
    try {
      const data = await BudgetService.getBudgetForMonth(selectedMonth, selectedYear);
      if (data) {
        setBudgetData(data);
        setIsDataAvailable(true);
      } else {
        setBudgetData(null);
        setIsDataAvailable(false); // No data available
      }
    } catch (error) {
      console.error("Error fetching budget:", error);
      setIsDataAvailable(false);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBudget();
  }, [selectedMonth, selectedYear]);

  const handleMonthChange = (event) => {
    setSelectedMonth(parseInt(event.target.value, 10));
  };

  const handleYearChange = (event) => {
    setSelectedYear(parseInt(event.target.value, 10));
  };

  const saveBudget = async (updatedBudget) => {
    try {
      const data = await BudgetService.saveBudget(updatedBudget);
    } catch (error) {
      console.error("Error saving budget:", error);
    }
  };

  const createNewBudget = async () => {
    if (!newBudgetName.trim()) {
      alert("Budget name cannot be empty.");
      return;
    }
    const newBudget = {
      name: newBudgetName,
      userId: localStorage.getItem('userId'),
      month: selectedMonth,
      year: selectedYear,
      incomeSources: [],
      fixedExpenses: [],
      variableExpenses: [],
      savingGoals: [],
    };

    try {
      const savedBudget = await BudgetService.saveBudget(newBudget);
      setBudgetData(newBudget);
      fetchBudget();
      setIsDataAvailable(true);
    } catch (error) {
      console.error("Error creating new budget:", error);
    }
  };

  const handleNameChange = (event) => {
    const { value } = event.target;
    setBudgetData((prevData) => ({
      ...prevData,
      name: value,
      userId: localStorage.getItem('userId')
    }));
    saveBudget({ ...budgetData, name: value, userId: localStorage.getItem('userId') });
  };

  const handleBackClick = () => {
    navigate("/home");
  };

  return (
    <div className="budget-image d-flex justify-content-center align-items-start mt-4 px-3" >
      <div className="w-100" style={{ maxWidth: "800px" }}>
        {/* Back Button */}
        <div className="mb-4">
          <button className="btn btn-outline-light" onClick={handleBackClick}>
            <FaArrowLeft size={20} />
            <span className="ms-2">Back</span>
          </button>
        </div>
  
        {/* Header */}
        <div className="text-center mb-4">
          <h2 className="text-light">Budget Overview</h2>
          <div className="d-flex justify-content-center flex-wrap gap-2 mt-3">
            <div>
              <label className="form-label text-light me-2 fw-bold">Month:</label>
              <select
                className="form-select"
                value={selectedMonth}
                onChange={handleMonthChange}
                style={{ width: "150px" }}
              >
                {Array.from({ length: 12 }, (_, i) => (
                  <option key={i + 1} value={i + 1}>
                    {new Date(0, i).toLocaleString("default", { month: "long" })}
                  </option>
                ))}
              </select>
            </div>
  
            <div>
              <label className="form-label text-secondary me-2 text-light fw-bold">Year:</label>
              <input
                type="number"
                className="form-control"
                value={selectedYear}
                onChange={handleYearChange}
                min="2000"
                max="2100"
                style={{ width: "150px" }}
              />
            </div>
          </div>
        </div>
  
        {/* Loading or No Data Message */}
        {isLoading ? (
          <div className="d-flex justify-content-center mt-5">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : !isDataAvailable ? (
          <div className="text-center mt-5">
            <p className="fw-semibold">No budget data available for the selected month and year.</p>
            <p>Would you like to create a new budget?</p>
            <div className="mb-3 mx-auto" style={{ maxWidth: "400px" }}>
              <input
                type="text"
                className="form-control mb-2 shadow-sm"
                placeholder="Enter budget name"
                value={newBudgetName}
                onChange={(e) => setNewBudgetName(e.target.value)}
              />
              <button
                onClick={createNewBudget}
                className="btn btn-success w-100 shadow-sm"
              >
                Create New Budget
              </button>
            </div>
          </div>
        ) : (
          <div className="card p-4 shadow-sm bg-white">
            <div className="mb-4">
              <label className="fw-bold text-dark">Budget Name:</label>
              <input
                className="form-control shadow-sm"
                type="text"
                value={budgetData?.name || ''}
                onBlur={handleNameChange}
              />
            </div>
  
            {/* Main Sections */}
            <div className="mb-4">
              <IncomeSection incomeSources={budgetData?.incomeSources || []} budgetId={budgetData?.budgetId} fetchBudget={fetchBudget} />
            </div>
  
            <div className="mb-4">
              <FixedExpensesSection expenses={budgetData?.fixedExpenses || []} budgetId={budgetData?.budgetId} fetchBudget={fetchBudget} />
            </div>
  
            <div className="mb-4">
              <VariableExpensesSection expenses={budgetData?.variableExpenses || []} budgetId={budgetData?.budgetId} fetchBudget={fetchBudget} />
            </div>
  
            <div className="mb-4">
              <SavingsGoalsSection savings={budgetData?.savingGoals || []} budgetId={budgetData?.budgetId} fetchBudget={fetchBudget} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
  
};

export default BudgetScreen;

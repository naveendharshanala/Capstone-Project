import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  FaRobot,
  FaChartPie,
  FaMoneyBillWave,
  FaWallet,
  FaTasks,
  FaTimes,
} from "react-icons/fa";
import "bootstrap/dist/css/bootstrap.min.css";
import "../css/Home.css";

const predefinedQA = {
  "how to create a budget": {
    answer: "To create a budget, go to the Budgets section.",
    action: "/budgets"
  },
  "how to track expenses": {
    answer: "Use the Expense Tracker tool to log your daily expenses.",
    action: "/expense-tracker"
  },
  "how to view dashboard": {
    answer: "Click on Dashboard to see your financial summary.",
    action: "/dashboard"
  },
  "how to add debt": {
    answer: "Navigate to Debt Tracker and fill in your loan or credit details.",
    action: "/debt-tracker"
  },
};

const Home = () => {
  const navigate = useNavigate();
  const [showBot, setShowBot] = useState(false);
  const [userInput, setUserInput] = useState("");
  const [chatHistory, setChatHistory] = useState([]);
  const [initialized, setInitialized] = useState(false);

  const tools = [
    { title: "Budgets", color: "success", icon: <FaWallet />, path: "/budgets" },
    { title: "Expense Tracker", color: "info", icon: <FaMoneyBillWave />, path: "/expense-tracker" },
    { title: "Dashboard", color: "primary", icon: <FaChartPie />, path: "/dashboard" },
    { title: "Debt Tracker", color: "danger", icon: <FaTasks />, path: "/debt-tracker" },
  ];

  const handleUserInput = () => {
    const lowerInput = userInput.toLowerCase().trim();
    const match = predefinedQA[lowerInput];

    const botMessage = match
      ? { type: "bot", message: match.answer, path: match.action }
      : { type: "bot", message: "Sorry, I didn't understand that. Please try a different question." };

    setChatHistory([...chatHistory, { type: "user", message: userInput }, botMessage]);
    setUserInput("");
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleUserInput();
  };

  useEffect(() => {
    if (showBot && !initialized) {
      const welcomeMessages = [
        { type: "bot", message: "👋 Hello User! How can I help you today?" },
        {
          type: "bot",
          message:
            "Here are some topics you can ask me about:\n• How to create a budget\n• How to track expenses\n• How to view dashboard\n• How to add debt",
        },
      ];
      setChatHistory(welcomeMessages);
      setInitialized(true);
    }
  }, [showBot, initialized]);

  return (
    <div
      className="home-wrapper text-white d-flex flex-column min-vh-100 w-100"
      style={{ backgroundImage: "url('lg-header-hero-desktop-cb-logo.jpg')" }}
    >
      <div className="container-fluid py-5 flex-grow-1">
        {/* Welcome Section */}
        <div className="text-center mb-5">
          <h1 className="display-5 fw-bold text-white">Welcome to Your Financial Hub</h1>
          <p className="text-light fs-5">Track expenses, manage your budget, and take control of your financial journey.</p>
        </div>

        {/* Tool Cards */}
        <div className="row g-4">
          {tools.map(({ title, color, icon, path }) => (
            <div className="col-md-6 col-lg-3" key={title}>
              <div className={`card border-0 shadow-sm bg-light h-100 hover-shadow`} role="button" onClick={() => navigate(path)}>
                <div className="card-body text-center">
                  <div className={`text-${color} mb-3`} style={{ fontSize: "2rem" }}>{icon}</div>
                  <h5 className="card-title fw-semibold text-dark">{title}</h5>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Floating Bot Icon */}
      <div
        className="floating-bot-icon bg-primary rounded-circle shadow d-flex justify-content-center align-items-center"
        style={{
          position: "fixed",
          bottom: "30px",
          right: "30px",
          width: "60px",
          height: "60px",
          cursor: "pointer",
          zIndex: 1000,
        }}
        onClick={() => setShowBot(true)}
      >
        <FaRobot size={30} color="#fff" />
      </div>

      {/* Chatbot Overlay */}
      {showBot && (
        <div
          className="chatbot-overlay position-fixed bottom-0 end-0 bg-white p-3 shadow-lg d-flex flex-column"
          style={{ width: "320px", height: "450px", borderRadius: "16px", zIndex: 1100 }}
        >
          {/* Header */}
          <div className="d-flex justify-content-between align-items-center mb-2">
            <h5 className="m-0 text-primary">Assistant Bot</h5>
            <FaTimes
              role="button"
              className="text-danger"
              onClick={() => {
                setShowBot(false);
                setChatHistory([]);
                setInitialized(false);
              }}
              style={{ cursor: "pointer", fontSize: "18px" }}
            />
          </div>

          {/* Chat History */}
          <div className="chat-history flex-grow-1 mb-2" style={{ overflowY: "auto", fontSize: "14px" }}>
            {chatHistory.map((chat, idx) => (
              <div key={idx} className={`mb-3 ${chat.type === "user" ? "text-end" : "text-start"}`}>
                <div
                  className={`d-inline-block px-3 py-2 rounded-3 ${chat.type === "user" ? "bg-primary text-white" : "bg-light text-dark"}`}
                  style={{ maxWidth: "85%", whiteSpace: "pre-line" }}
                >
                  {chat.message}
                  {chat.path && (
                    <div className="mt-2">
                      <button className="btn btn-sm btn-outline-primary" onClick={() => navigate(chat.path)}>
                        Go
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Input Area */}
          <div>
            <input
              type="text"
              className="form-control"
              placeholder="Ask a question..."
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyDown={handleKeyDown}
            />
            <button className="btn btn-sm btn-primary mt-2 w-100" onClick={handleUserInput}>
              Send
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;

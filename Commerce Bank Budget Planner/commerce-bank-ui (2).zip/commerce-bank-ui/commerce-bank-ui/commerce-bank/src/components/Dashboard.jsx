import React, { useEffect, useState } from "react";
import { Bar, Doughnut } from "react-chartjs-2";
import {
  Chart,
  CategoryScale,
  ArcElement,
  BarElement,
  Tooltip,
  Legend,
  LinearScale,
} from "chart.js";
import "../css/Dashboard.css";
import { useNavigate } from "react-router-dom";
import ExpenseService from "../api/ExpenseService";
import BudgetService from "../api/BudgetService";
import { IoCaretBack } from "react-icons/io5";

// Register Chart.js components
Chart.register(
  CategoryScale,
  ArcElement,
  BarElement,
  Tooltip,
  Legend,
  LinearScale
);

const Dashboard = () => {
  const selectedMonth = new Date().getMonth() + 1;
  const selectedYear = new Date().getFullYear();
  const [budgetSummary, setBudgetSummary] = useState({
    income: 0,
    expenses: 0,
  });
  const [expenseCategories, setExpenseCategories] = useState({
    fixed: { rent: 0, subscription: 0, utilities: 0 },
    variable: { dining: 0, groceries: 0, transportation: 0 },
  });
  const [notifications, setNotifications] = useState([]);
  const [showBadge, setShowBadge] = useState(false);

  const navigate = useNavigate();
  const ALERT_THRESHOLD = 0.3;

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const data = await BudgetService.getBudgetForMonth(
          selectedMonth,
          selectedYear
        );
        if (data) {
          const income = data.incomeSources.reduce(
            (acc, src) => acc + parseFloat(src.amount),
            0
          );
          const expenseData = await ExpenseService.getDashboardData(
            selectedMonth
          );

          const additionalIncome =
            expenseData.data.categorySpending["Additional Income"] || 0;
          let totalExpenses =
            Object.values(expenseData.data.categorySpending).reduce(
              (acc, curr) => acc + parseFloat(curr),
              0
            ) - additionalIncome;
          const totalIncome = income + additionalIncome;

          setBudgetSummary({ income: totalIncome, expenses: totalExpenses });
          setShowBadge(totalExpenses < totalIncome);

          const spending = expenseData.data.categorySpending;
          setExpenseCategories({
            fixed: {
              rent: spending["Rent"] || 0,
              subscription: spending["Entertainment"] || 0,
              utilities: spending["Utilities"] || 0,
            },
            variable: {
              dining: spending["Dining Out"] || 0,
              groceries: spending["Groceries"] || 0,
              transportation: spending["Transportation"] || 0,
            },
          });

          const alerts = [];
          Object.entries(spending).forEach(([category, amount]) => {
            if (
              category !== "Additional Income" &&
              amount >= totalIncome * ALERT_THRESHOLD
            ) {
              alerts.push({
                category,
                message: `⚠️ Spending in "${category}" is nearing your budget limit.`,
              });
            }
          });

          setNotifications(alerts);
        }
      } catch (error) {
        console.error("Error loading dashboard data:", error);
      }
    };
    fetchDashboardData();
  }, []);

  const chartData = {
    labels: [
      "Rent",
      "Subscription",
      "Utilities",
      "Dining",
      "Groceries",
      "Transportation",
    ],
    datasets: [
      {
        label: "Expenses",
        data: [
          expenseCategories.fixed.rent,
          expenseCategories.fixed.subscription,
          expenseCategories.fixed.utilities,
          expenseCategories.variable.dining,
          expenseCategories.variable.groceries,
          expenseCategories.variable.transportation,
        ],
        backgroundColor: [
          "#FF6384",
          "#36A2EB",
          "#FFCE56",
          "#4BC0C0",
          "#9966FF",
          "#FF9F40",
        ],
      },
    ],
  };

  const handleBackClick = () => navigate("/home");

  return (
    <div className="dashboard-wrapper">
      <div className="btn btn-dark align-items-center" onClick={handleBackClick}>
      <IoCaretBack />
        <span>Back</span>
      </div>

      {notifications.length > 0 && (
        <div className="notifications-box">
          {notifications.map((note, idx) => (
            <div key={idx} className="notification-card">
              {note.message}
            </div>
          ))}
        </div>
      )}

      <div className="summary-card-group">
        <div className="summary-card">
          <h4>Total Income</h4>
          <p>${budgetSummary.income.toFixed(2)}</p>
        </div>
        <div className="summary-card">
          <h4>Total Expenses</h4>
          <p>${budgetSummary.expenses.toFixed(2)}</p>
        </div>
        <div className="summary-card">
          <h4>Balance</h4>
          <p>${(budgetSummary.income - budgetSummary.expenses).toFixed(2)}</p>
        </div>
      </div>

      {showBadge && (
        <div className="congrats-banner">
          <img
            src="/certificate-solid.svg"
            alt="Badge"
            className="badge-icon"
          />
          🎉 Great job! You stayed within your budget this month!
        </div>
      )}

      <div className="charts-section">
        <div className="chart-card">
          <h5>Spending Breakdown</h5>
          <div className="chart-wrapper">
            <Doughnut
              data={chartData}
              options={{ responsive: true, maintainAspectRatio: false }}
            />
          </div>
        </div>

        <div className="chart-card">
          <h5>Category-wise Expenses</h5>
          <div className="chart-wrapper">
            <Bar
              data={chartData}
              options={{ responsive: true, maintainAspectRatio: false }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

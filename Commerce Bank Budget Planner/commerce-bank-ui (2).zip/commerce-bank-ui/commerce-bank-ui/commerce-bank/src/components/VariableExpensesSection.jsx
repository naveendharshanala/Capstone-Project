import React, { useEffect, useState } from "react";
import CollapsibleSection from "./CollapsibleSection";
import BudgetService from "../api/BudgetService";
import { FaRegMoneyBillAlt } from "react-icons/fa"; // Optional icon for variable expenses
import "../css/BudgetScreen.css";

const VariableExpensesSection = ({ expenses, budgetId, fetchBudget }) => {
  const [variableExpenses, setVariableExpenses] = useState([]);

  // Use useEffect to set variableExpenses based on expenses prop
  useEffect(() => {
    if (expenses && expenses.length > 0) {
      setVariableExpenses(expenses);
    } else {
      setVariableExpenses([
        { id: null, budgetId: budgetId, category: "Groceries", amount: 0 },
        { id: null, budgetId: budgetId, category: "Transportation", amount: 0 },
        { id: null, budgetId: budgetId, category: "Dining-Out", amount: 0 },
      ]);
    }
  }, [expenses, budgetId]);

  const handleInputChange = (index, event) => {
    const { value } = event.target;
    const updatedExpenses = [...variableExpenses];
    updatedExpenses[index].amount = value; // Update the amount for the specific expense
    setVariableExpenses(updatedExpenses);
  };

  const handleSave = async () => {
    try {
      console.log("Variable Expenses before save:", variableExpenses);
      await BudgetService.saveVariableExpenses(variableExpenses, budgetId);
      fetchBudget(); // Refresh the budget data
    } catch (error) {
      console.error("Failed to save variable expenses:", error);
    }
  };

  return (
    <CollapsibleSection title="Variable Expenses">
      <div className="income-form p-4 border rounded-3 bg-light shadow-sm">
        <h5 className="mb-3 text-primary">
          <FaRegMoneyBillAlt className="me-2" />
          Variable Expenses
        </h5>
        {variableExpenses.map((expense, index) => (
          <div className="input-item mb-3" key={expense.category}>
            <label htmlFor={expense.category} className="form-label text-dark">
              {expense.category}
            </label>
            <input
              id={expense.category}
              className="form-control form-control-lg"
              type="number"
              name="amount"
              value={expense.amount}
              onChange={(event) => handleInputChange(index, event)}
              placeholder="Amount"
            />
          </div>
        ))}
      </div>
      <div className="budget-footer text-center mt-4">
        <button
          className="btn btn-success btn-lg px-4 py-2"
          onClick={handleSave}
        >
          <FaRegMoneyBillAlt className="me-2" />
          Save Variable Expenses
        </button>
      </div>
    </CollapsibleSection>
  );
};

export default VariableExpensesSection;

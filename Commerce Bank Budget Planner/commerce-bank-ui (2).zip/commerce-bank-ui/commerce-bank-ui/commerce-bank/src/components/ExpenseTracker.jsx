import React, { useState, useEffect } from "react";
import "../css/ExpenseTracker.css";
import { useNavigate } from "react-router-dom";
import ExpenseService from "../api/ExpenseService";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css"; 
import "../css/Dashboard.css"
import { IoCaretBack } from "react-icons/io5";


const predefinedCategories = [
  "Rent",
  "Groceries",
  "Dining Out",
  "Transportation",
  "Entertainment",
  "Utilities",
  "Additional Income",
];

const categoryColors = {
  Rent: "text-danger",
  Groceries: "text-success",
  "Dining Out": "text-warning",
  Transportation: "text-info",
  Entertainment: "text-primary",
  Utilities: "text-secondary",
  "Additional Income": "text-success",
};

const ExpenseTracker = () => {
  const [selectedDate, setSelectedDate] = useState("");
  const [expenses, setExpenses] = useState({
    Rent: { amount: "", id: null },
    Groceries: { amount: "", id: null },
    "Dining Out": { amount: "", id: null },
    Transportation: { amount: "", id: null },
    Entertainment: { amount: "", id: null },
    Utilities: { amount: "", id: null },
    "Additional Income": { amount: "", id: null },
  });
  const [totalExpenses, setTotalExpenses] = useState(0);

  const navigate = useNavigate();

  useEffect(() => {
    if (selectedDate) {
      fetchExpensesForDate(selectedDate);
    }
  }, [selectedDate]);

  const fetchExpensesForDate = async (date) => {
    try {
      const response = await ExpenseService.getExpensesForDate(date);
      const data = response.data;

      if (data.length === 0) {
        setExpenses({
          Rent: { amount: "", id: null },
          Groceries: { amount: "", id: null },
          "Dining Out": { amount: "", id: null },
          Transportation: { amount: "", id: null },
          Entertainment: { amount: "", id: null },
          Utilities: { amount: "", id: null },
          "Additional Income": { amount: "", id: null },
        });
      } else {
        const fetchedExpenses = data.reduce((acc, expense) => {
          acc[expense.category] = { amount: expense.amount, id: expense.id };
          return acc;
        }, {});
        setExpenses((prevExpenses) => ({
          ...prevExpenses,
          ...fetchedExpenses,
        }));
        const total = data.reduce((sum, expense) => {
          return expense.category !== "Additional Income"
            ? sum + parseFloat(expense.amount)
            : sum;
        }, 0);
        setTotalExpenses(total);
      }
    } catch (error) {
      console.error("Error fetching expenses:", error);
      toast.error("Failed to fetch expenses.");
    }
  };

  const handleDateChange = (e) => setSelectedDate(e.target.value);

  const handleExpenseChange = (category, amount) => {
    setExpenses((prevExpenses) => ({
      ...prevExpenses,
      [category]: {
        ...prevExpenses[category],
        amount,
      },
    }));
  };

  const logExpenses = async () => {
    const newLoggedExpenses = Object.entries(expenses)
      .filter(([_, { amount }]) => amount !== "")
      .map(([category, { amount, id }]) => ({
        expenseDate: selectedDate,
        category,
        amount,
        id,
      }));

    if (newLoggedExpenses.length === 0) {
      toast.warn("Please enter at least one expense.");
      return;
    }

    try {
      await ExpenseService.saveExpenses(newLoggedExpenses);
      toast.success("Expenses saved successfully!");

      const total = newLoggedExpenses.reduce((sum, expense) => {
        return expense.category !== "Additional Income"
          ? sum + parseFloat(expense.amount)
          : sum;
      }, 0);
      setTotalExpenses(total);
      fetchExpensesForDate(selectedDate);
    } catch (error) {
      console.error("Error saving expenses:", error);
      toast.error("Error saving expenses.");
    }
  };

  const handleBackClick = () => {
    navigate("/home");
  };

  return (
    <div
      className="container-fluid d-flex justify-content-center align-items-center dashboard-wrapper"
      style={{ paddingTop: "80px", minHeight: "100vh" }}
    >
      <ToastContainer position="top-right" autoClose={3000} />
      <div className="col-md-6 col-lg-5">
        <div className="btn btn-dark align-items-center mb-5" onClick={handleBackClick}>
        <IoCaretBack />
          <span>Back</span>
        </div>
 

        <div className="card shadow">
          <div className="card-body">
            <h2 className="text-center mb-4">Expense Tracker</h2>

            <div className="mb-4">
              <label className="form-label">Select Date:</label>
              <input
                type="date"
                className="form-control"
                value={selectedDate}
                onChange={handleDateChange}
              />
            </div>

            {predefinedCategories.map((category) => (
              <div className="mb-3" key={category}>
                <label className={`form-label fw-semibold ${categoryColors[category]}`}>
                  {category}:
                </label>
                <input
                  type="number"
                  className="form-control"
                  value={expenses[category].amount}
                  onChange={(e) =>
                    handleExpenseChange(category, e.target.value)
                  }
                  placeholder={`Enter ${category} amount`}
                />
              </div>
            ))}

            <button
              className="btn btn-primary w-100 mt-3"
              onClick={logExpenses}
              disabled={!selectedDate}
            >
              Log Expenses
            </button>

            <div className="mt-4 text-center border-top pt-3">
              <h5 className="text-dark">Total Expenses for {selectedDate}</h5>
              <p className="fw-bold fs-4 text-success">
                ${totalExpenses.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExpenseTracker;

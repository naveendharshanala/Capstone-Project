import React, { useEffect, useState } from "react";
import CollapsibleSection from "./CollapsibleSection";
import BudgetService from "../api/BudgetService";
import { FaPiggyBank } from "react-icons/fa"; // Optional icon for savings goals

const SavingsGoalsSection = ({ savings, budgetId, fetchBudget }) => {
  const [savingsGoals, setSavingsGoals] = useState([]);

  // Use useEffect to set savingsGoals based on savings prop
  useEffect(() => {
    if (savings && savings.length > 0) {
      setSavingsGoals(savings);
    } else {
      setSavingsGoals([
        { id: null, budgetId: budgetId, name: "Vacation", amount: 0 },
        { id: null, budgetId: budgetId, name: "Emergency fund", amount: 0 },
        { id: null, budgetId: budgetId, name: "Retirement", amount: 0 },
      ]);
    }
  }, [savings, budgetId]);

  const handleInputChange = (index, event) => {
    const { value } = event.target;
    const updatedSavingsGoals = [...savingsGoals];
    updatedSavingsGoals[index].amount = value; // Update the amount for the specific savings goal
    setSavingsGoals(updatedSavingsGoals);
  };

  const handleSave = async () => {
    try {
      console.log("Savings Goals before save:", savingsGoals);
      await BudgetService.saveSavingsGoals(savingsGoals, budgetId);
      fetchBudget(); // Refresh the budget data
    } catch (error) {
      console.error("Failed to save savings goals:", error);
    }
  };

  return (
    <CollapsibleSection title="Saving Goals">
      <div className="p-4 border rounded-3 bg-light shadow-sm">
        <h5 className="mb-3 text-primary">
          <FaPiggyBank className="me-2" />
          Saving Goals
        </h5>
        {savingsGoals.map((goal, index) => (
          <div className="mb-3" key={goal.name}>
            <label htmlFor={goal.name} className="form-label text-dark">
              {goal.name}
            </label>
            <input
              id={goal.name}
              className="form-control form-control-lg"
              type="number"
              name="amount"
              value={goal.amount}
              onChange={(event) => handleInputChange(index, event)}
              placeholder="Amount"
            />
          </div>
        ))}
      </div>
      <div className="text-center mt-4">
        <button
          className="btn btn-success btn-lg px-4 py-2"
          onClick={handleSave}
        >
          <FaPiggyBank className="me-2" />
          Save Savings Goals
        </button>
      </div>
    </CollapsibleSection>
  );
};

export default SavingsGoalsSection;

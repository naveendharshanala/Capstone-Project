import React, { useState } from "react";

const CollapsibleSection = ({ title, children }) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSection = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="card shadow-sm mb-3">
      <div
        className="card-header d-flex justify-content-between align-items-center bg-primary text-white"
        style={{ cursor: "pointer" }}
        onClick={toggleSection}
      >
        <h5 className="mb-0">{title}</h5>
        <span className="fs-4">{isOpen ? "▲" : "▼"}</span>
      </div>
      {isOpen && (
        <div className="card-body bg-light">
          {children}
        </div>
      )}
    </div>
  );
};

export default CollapsibleSection;

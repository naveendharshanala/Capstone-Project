import React, { useState, useEffect } from 'react';
import DebtService from '../api/DebtService';
import { useNavigate } from 'react-router-dom';
// import "../css/Dashboard.css"
import { IoCaretBack } from "react-icons/io5";

const DebtTracker = () => {
  const [debts, setDebts] = useState([]);
  const [newDebt, setNewDebt] = useState({
    type: '',
    amount: '',
    interestRate: '',
    minPayment: '',
    additionalPayment: '',
    userId: parseInt(localStorage.getItem('userId'))
  });
  const [suggestions, setSuggestions] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDebts = async () => {
      try {
        const userDebts = await DebtService.getDebtsByUserId(localStorage.getItem('userId'));
        setDebts(userDebts);
        generateSuggestions(userDebts);
      } catch (error) {
        console.error('Failed to fetch debts:', error);
      }
    };
    fetchDebts();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewDebt((prevDebt) => ({
      ...prevDebt,
      [name]: value,
    }));
  };

  const formattedDebt = {
    ...newDebt,
    amount: parseFloat(newDebt.amount),
    interestRate: parseFloat(newDebt.interestRate),
    minPayment: parseFloat(newDebt.minPayment),
    additionalPayment: parseFloat(newDebt.additionalPayment || 0),
  };

  const addDebt = async () => {
    try {
      const savedDebt = await DebtService.saveDebt(formattedDebt);
      setDebts([...debts, savedDebt]);
      setNewDebt({
        type: '',
        amount: '',
        interestRate: '',
        minPayment: '',
        additionalPayment: ''
      });
      generateSuggestions([...debts, savedDebt]);
    } catch (error) {
      console.error('Failed to save debt:', error);
    }
  };

  const generateSuggestions = (debts) => {
    const totalInterestRate = debts.reduce((acc, debt) => acc + parseFloat(debt.interestRate), 0);
    const newSuggestions = [];

    if (debts.length > 1) {
      newSuggestions.push(
        'Consider using the Snowball method: focus on paying off the smallest debt first.'
      );
    }

    if (totalInterestRate / debts.length > 15) {
      newSuggestions.push(
        'Try the Avalanche method: pay off the debt with the highest interest rate first.'
      );
    }

    setSuggestions(newSuggestions);
  };

  const handleBackClick = () => {
    navigate("/home");
  };

  return (
    <div className="container-fluid my-4 dashboard-wrapper pb-5">
    <div className="row justify-content-center">
      <div className="col-lg-10">
  
        {/* Back Button */}
           <div className="btn btn-dark  align-items-center mb-5" onClick={handleBackClick}>
               <IoCaretBack />
                 <span>Back</span>
               </div>
  
        <h2 className="text-light mb-4 text-center">Debt Tracker</h2>
  
        {/* Debt Input Form */}
        <div className="card p-4 mb-4 w-100 no-shadow">
          <h4>Add New Debt</h4>
          <div className="row g-3">
            {['type', 'amount', 'interestRate', 'minPayment', 'additionalPayment'].map((field, idx) => (
              <div className="col-md-6" key={idx}>
                <input
                  type={field === 'type' ? 'text' : 'number'}
                  name={field}
                  className="form-control"
                  placeholder={
                    field === 'type'
                      ? 'Debt Type (e.g., Student Loan, Credit Card)'
                      : field === 'amount'
                      ? 'Debt Amount ($)'
                      : field === 'interestRate'
                      ? 'Interest Rate (%)'
                      : field === 'minPayment'
                      ? 'Minimum Monthly Payment ($)'
                      : 'Additional Payment ($)'
                  }
                  value={newDebt[field]}
                  onChange={handleInputChange}
                />
              </div>
            ))}
          </div>
          <button className="btn btn-success mt-3" onClick={addDebt}>
            Add Debt
          </button>
        </div>
  
        {/* Current Debts */}
        <div className="card p-4 mb-4 w-100">
          <h4>Current Debts</h4>
          {debts.length > 0 ? (
            <ul className="list-group">
              {debts.map((debt, index) => (
                <li className="list-group-item" key={index}>
                  <strong>{debt.type}</strong>: ${debt.amount} at {debt.interestRate}% interest — 
                  Min Payment: ${debt.minPayment}, Additional: ${debt.additionalPayment}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-muted">No debts added yet.</p>
          )}
        </div>
  
        {/* Repayment Suggestions */}
        <div className="card p-4 mb-4 w-100">
          <h4>Repayment Strategies</h4>
          {suggestions.length > 0 ? (
            <ul className="list-group">
              {suggestions.map((suggestion, index) => (
                <li className="list-group-item" key={index}>
                  {suggestion}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-muted">No suggestions at this time.</p>
          )}
        </div>
  
        {/* Summary Section */}
        <div className="card p-4 w-100">
          <h4>Debt Summary</h4>
          <p><strong>Total Debt:</strong> ${debts.reduce((acc, d) => acc + parseFloat(d.amount), 0).toFixed(2)}</p>
          <p>
            <strong>Total Monthly Payment:</strong> ${debts.reduce(
              (acc, d) => acc + parseFloat(d.minPayment) + parseFloat(d.additionalPayment || 0), 0
            ).toFixed(2)}
          </p>
        </div>
  
      </div>
    </div>
  </div>
  
  );
};

export default DebtTracker;

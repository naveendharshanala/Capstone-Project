import React from "react";
import { useNavigate } from "react-router-dom";
import { FiLogOut } from "react-icons/fi";

const Layout = ({ children }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <div className="layout d-flex flex-column min-vh-100 w-100" style={{ overflow: "hidden" }}>
      {/* Fixed-top Navbar */}
      <nav className="navbar navbar-dark bg-dark text-light shadow-sm fixed-top w-100 d-flex justify-content-between align-items-center px-3">
        <div className="d-flex justify-content-between w-100 align-items-center">
          <div className="d-flex align-items-center">
            <img
              src="/image.png"
              alt="Logo"
              width="36"
              height="36"
              className="rounded-circle me-2 bg-dark"
            />
            <h4 className="mb-0 fw-bold text-light">Commerce Bank</h4>
          </div>

          <div className="d-flex align-items-center">
            <button
              className="btn btn-link text-dark d-lg-none"
              onClick={handleLogout}
              aria-label="Logout"
            >
              <FiLogOut size={22} />
            </button>
            <button
              className="btn btn-light d-none d-lg-flex align-items-center"
              onClick={handleLogout}
            >
              <FiLogOut className="me-1" size={20} />
              Logout
            </button>
          </div>
        </div>
      </nav>

      {/* Children Section */}
      <div className="container-fluid py-4" style={{ paddingLeft: "0", paddingRight: "0", marginTop: "20px", overflowY: "auto", height: "100%" }}>
        {children}
      </div>
    </div>
  );
};

export default Layout;

import React, { useEffect, useState } from "react";
import CollapsibleSection from "./CollapsibleSection";
import BudgetService from "../api/BudgetService";
import { FaRegMoneyBillAlt } from "react-icons/fa"; // Optional icon for fixed expenses
import "../css/BudgetScreen.css";

const FixedExpensesSection = ({ expenses, budgetId, fetchBudget }) => {
  const [fixedExpenses, setFixedExpenses] = useState([]);

  // Use useEffect to set fixedExpenses based on expenses prop
  useEffect(() => {
    if (expenses && expenses.length > 0) {
      setFixedExpenses(expenses);
    } else {
      setFixedExpenses([
        { id: null, budgetId: budgetId, category: "Rent", amount: 0 },
        { id: null, budgetId: budgetId, category: "Utilities", amount: 0 },
        { id: null, budgetId: budgetId, category: "Subscriptions", amount: 0 },
      ]);
    }
  }, [expenses, budgetId]);

  const handleInputChange = (index, event) => {
    const { value } = event.target;
    const updatedExpenses = [...fixedExpenses];
    updatedExpenses[index].amount = value; // Update the amount for the specific expense
    setFixedExpenses(updatedExpenses);
  };

  const handleSave = async () => {
    try {
      console.log("Fixed Expenses before save:", fixedExpenses);
      await BudgetService.saveFixedExpenses(fixedExpenses, budgetId);
      fetchBudget(); // Refresh the budget data
    } catch (error) {
      console.error("Failed to save fixed expenses:", error);
    }
  };

  return (
    <CollapsibleSection title="Fixed Expenses">
      <div className="income-form p-4 border rounded-3 bg-light shadow-sm">
        <h5 className="mb-3 text-primary">
          <FaRegMoneyBillAlt className="me-2" />
          Fixed Expenses
        </h5>
        {fixedExpenses.map((expense, index) => (
          <div className="input-item mb-3" key={expense.category}>
            <label htmlFor={expense.category} className="form-label text-dark">
              {expense.category}
            </label>
            <input
              id={expense.category}
              className="form-control form-control-lg"
              type="number"
              name="amount"
              value={expense.amount}
              onChange={(event) => handleInputChange(index, event)}
              placeholder="Amount"
            />
          </div>
        ))}
      </div>
      <div className="budget-footer text-center mt-4">
        <button
          className="btn btn-success btn-lg px-4 py-2"
          onClick={handleSave}
        >
          <FaRegMoneyBillAlt className="me-2" />
          Save Fixed Expenses
        </button>
      </div>
    </CollapsibleSection>
  );
};

export default FixedExpensesSection;

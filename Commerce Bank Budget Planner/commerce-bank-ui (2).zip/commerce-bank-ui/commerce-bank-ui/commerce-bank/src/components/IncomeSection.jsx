import React, { useEffect, useState } from "react";
import CollapsibleSection from "./CollapsibleSection";
import BudgetService from "../api/BudgetService";
import { FaMoneyBillAlt } from "react-icons/fa"; // Optional icon for income sources

const IncomeSection = ({ incomeSources, budgetId, fetchBudget }) => {
  // Initialize state for income sources
  const [incomeData, setIncomeData] = useState([]);

  // Use useEffect to set incomeData based on incomeSources prop
  useEffect(() => {
    if (incomeSources && incomeSources.length > 0) {
      setIncomeData(incomeSources);
    } else {
      setIncomeData([
        { id: null, budgetId: budgetId, sourceName: "Allowances", amount: 0 },
        { id: null, budgetId: budgetId, sourceName: "Part-time", amount: 0 },
        { id: null, budgetId: budgetId, sourceName: "Scholarships", amount: 0 },
      ]);
    }
  }, [incomeSources, budgetId]);

  const handleInputChange = (index, event) => {
    const { value } = event.target;
    const updatedIncomeSources = [...incomeData];
    updatedIncomeSources[index].amount = value;
    setIncomeData(updatedIncomeSources);
  };

  const handleSave = async () => {
    try {
      console.log("Income Sources before save:", incomeData);
      await BudgetService.saveIncomeSources(incomeData, budgetId);
      fetchBudget(); // Refresh the budget data
    } catch (error) {
      console.error("Failed to save income sources:", error);
    }
  };

  return (
    <CollapsibleSection title="Income">
      <div className="income-form p-4 border rounded-3 bg-light shadow-sm">
        <h5 className="mb-3 text-primary">
          <FaMoneyBillAlt className="me-2" />
          Income Sources
        </h5>
        {incomeData.map((income, index) => (
          <div className="input-item mb-3" key={income.sourceName}>
            <label htmlFor={income.sourceName} className="form-label text-dark">
              {income.sourceName}
            </label>
            <input
              id={income.sourceName}
              className="form-control form-control-lg"
              type="number"
              name="amount"
              value={income.amount}
              onChange={(event) => handleInputChange(index, event)}
              placeholder="Amount"
            />
          </div>
        ))}
      </div>
      <div className="budget-footer text-center mt-4">
        <button
          className="btn btn-success btn-lg px-4 py-2"
          onClick={handleSave}
        >
          <FaMoneyBillAlt className="me-2" />
          Save Income Sources
        </button>
      </div>
    </CollapsibleSection>
  );
};

export default IncomeSection;

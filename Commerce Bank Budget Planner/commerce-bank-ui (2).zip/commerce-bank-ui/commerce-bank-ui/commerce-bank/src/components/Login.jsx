import React, { useState } from "react";
import axiosInstance from "../axiosConfig";
import { useNavigate, Link } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify"; // Import ToastContainer and toast
import "react-toastify/dist/ReactToastify.css"; // Import Toastify styles
import "../css/Login.css";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false); // Track loading state
  const navigate = useNavigate(); // For navigation

  const isFormValid = username && password;

  const handleLogin = async (e) => {
    e.preventDefault();
    if (isFormValid) {
      setIsLoading(true); // Show spinner during login
      try {
        const response = await axiosInstance.post("/api/user/login", {
          email: username,
          password: password,
        });

        if (response.status === 200) {
          const token = response.data.token;
          const userId = response.data.userId;
          localStorage.setItem("userId", userId);
          localStorage.setItem("token", token);
          setIsLoading(false); // Stop spinner
          toast.success("Successfully logged in!"); // Show success toast
          setTimeout(() => navigate("/home"), 2000); // Delay navigation to show toast
        } else {
          setIsLoading(false);
          toast.error("Invalid username or password. Please try again."); // Show error toast
        }
      } catch (error) {
        setIsLoading(false);
        toast.error("Failed to fetch expenses. Please try again later."); // Show error toast
      }
    } else {
      toast.error("Please enter both username and password."); // Show error toast if form is incomplete
    }
  };

  const openRegister = () => {
    navigate("/register");
  };

  return (
    <div className="login-background d-flex justify-content-center align-items-center min-vh-100" style={{backgroundImage: "url('./Commerce-Garden-City-Exterior-6-1680x1075.jpg')"}}>
      <div
        className="login-box p-4 rounded shadow-lg w-100"
        style={{ maxWidth: "400px" }}
      >
        <div className="d-flex align-items-center justify-content-center mb-4 gap-2">
          <img
            src="/image.png"
            alt="Logo"
            className="logo-image"
            style={{ width: "50px" }}
          />
          <h4 className="mb-0 text-white fw-bold">Commerce Bank</h4>
        </div>

        <h3 className="text-center mb-4 fw-bold text-light">Login</h3>
        <form onSubmit={handleLogin} className="login-form">
          <div className="mb-3">
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="form-control form-control-lg"
              required
            />
          </div>
          <div className="mb-3">
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="form-control form-control-lg"
              required
            />
          </div>
          {errorMessage && (
            <p className="text-danger text-center">{errorMessage}</p>
          )}
          <button
            type="submit"
            disabled={!isFormValid || isLoading}
            className="btn btn-success w-100 py-2"
          >
            {isLoading ? (
              <div
                className="spinner-border spinner-border-sm text-light"
                role="status"
              >
                <span className="visually-hidden">Loading...</span>
              </div>
            ) : (
              "Login"
            )}
          </button>
        </form>
        <div className="d-flex justify-content-center mt-3 text-light">
          <button
            type="button"
            onClick={openRegister}
            className="btn btn-link text-light p-0"
          >
            Create new account
          </button>
        </div>
      </div>

      {/* Toast Container for all toast notifications */}
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar
        newestOnTop
        closeButton={false}
        pauseOnHover
      />
    </div>
  );
};

export default Login;

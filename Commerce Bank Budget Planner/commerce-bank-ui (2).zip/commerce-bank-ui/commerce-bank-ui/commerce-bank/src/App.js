import React from "react";
import {
  Navigate,
  BrowserRouter as Router,
  Route,
  Routes,
} from "react-router-dom";
import Home from "./components/Home";
import Login from "./components/Login";
import Register from "./components/Register";
import BudgetScreen from "./components/BudgetScreen";
import ExpenseTracker from "./components/ExpenseTracker";
import Layout from "./components/Layout";
import Dashboard from "./components/Dashboard";
import Trends from "./components/Trends";
import DebtTracker from "./components/DebtTracker";
import FinancialGrowthInsights from "./components/FinancialGrowthInsights";
import "./App.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const App = () => {
  return (
    <Router>
      <ToastContainer
        position="top-right"  // Change position to top-right
        autoClose={3000}  // Auto close after 3 seconds
        hideProgressBar={true}  // Hide progress bar
        newestOnTop={true}  // Toasts appear on top of older ones
        closeButton={false}  // Hide the close button (optional)
        rtl={false}  // Set to true if you are using right-to-left layout
      />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/home" element={<Layout><Home /></Layout>} />
        <Route path="/budgets" element={<Layout><BudgetScreen /></Layout>} />
        <Route path="/expense-tracker" element={<Layout><ExpenseTracker /></Layout>} />
        <Route path="/dashboard" element={<Layout><Dashboard /></Layout>} />
        <Route path="/trends" element={<Layout><Trends /></Layout>} />
        <Route path="/debt-tracker" element={<Layout><DebtTracker /></Layout>} />
        <Route path="/investment-insights" element={<Layout><FinancialGrowthInsights /></Layout>} />
      </Routes>
    </Router>
  );
};

export default App;
